// Courses Components - Exports
export { default as CoursesGridArea } from './CoursesGridArea';
export { default as CoursesDetailsArea } from './CoursesDetailsArea';
export { default as RelatedCourses } from './RelatedCourses';
