// Profile Components - Exports
export { default as UserProfileArea } from './UserProfileArea';
